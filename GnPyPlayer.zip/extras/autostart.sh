cd /var/www/html/GnPyPlayer/extras/
/usr/bin/python3 GnUpdate.py
