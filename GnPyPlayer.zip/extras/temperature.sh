while true
do
	vcgencmd measure_temp
	sleep 5s
done